import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import shapely.wkt
import metpy.calc as mpcalc
# install using $ conda install -c conda-forge metpy or $ pip install metpy
from metpy.units import units
import numpy as np

## U
csv=pd.read_csv('U.csv')

polygons=csv['geometry']
geometry=[shapely.wkt.loads(p) for p in polygons]

crs={'init':'epsg:4326'}
u = gpd.GeoDataFrame(csv, crs=crs, geometry=geometry)

## V

csv=pd.read_csv('V.csv')

polygons=csv['geometry']
geometry=[shapely.wkt.loads(p) for p in polygons]

crs={'init':'epsg:4326'}
v = gpd.GeoDataFrame(csv, crs=crs, geometry=geometry)

month='0005-05'
world=gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))

fig, ax = plt.subplots(figsize=(15, 15))
u.plot(ax=ax,column=month,legend=True,cmap='viridis',legend_kwds={'label': 'zonal wind, m/s','orientation': "horizontal"})
world.plot(ax=ax,facecolor='none', edgecolor='black')
plt.title('Zonal Wind for First Month of Nuclear Winter,  May of Simulation Year 5')
plt.show()


wspd=pd.read_csv('windSpeed.csv')

###########################################################################
######## Praneeth's code
#######################################################
# names of the months
times=u.columns[3:-1]
# new data frame for wind directions
wind_direction=pd.DataFrame(columns=times)

# define function to get wind direction from u and v
def wd(x,y):
    return mpcalc.wind_direction(units.Quantity(x, "m/s"),units.Quantity(y, "m/s"),convention='from')

#######################
for col_name in times:
    wind_direction[col_name]=wd(u[col_name].to_numpy(),v[col_name].to_numpy()).magnitude

############## get the wind direction quadrants
# fix the inequalities later
dir_N=(wind_direction>315) | (wind_direction<45)
dir_E=(wind_direction>45) & (wind_direction<135)
dir_S=(wind_direction>135) & (wind_direction<225)
dir_W=(wind_direction>225) & (wind_direction<315)

# construct windspeed dataframe (the one in csv format is in complete)

wind_speed=pd.DataFrame(columns=times)

for col_name in times:
    wind_speed[col_name]=np.sqrt(u[col_name]**2+v[col_name]**2)

# convert m/s to knot for the wind speed -wave height relationship

wind_speed=wind_speed*1.944


### relate the windspeed-waveheight relation using the reference from NOAA, refer equations in the excel
wave_height=pd.DataFrame().reindex_like(wind_speed)

wave_height[dir_N]=0.0067*wind_speed[dir_N]**2+0.0213*wind_speed[dir_N]+2.0746
wave_height[dir_E]=0.0085*wind_speed[dir_E]**2+0.0207*wind_speed[dir_E]+2.2443
wave_height[dir_S]=0.0037*wind_speed[dir_S]**2+0.0476*wind_speed[dir_S]+1.8165
wave_height[dir_W]=0.007*wind_speed[dir_W]**2-0.009*wind_speed[dir_W]+1.7429

################# create a geopandas dataframe for wave_height for plotting

wvht=gpd.GeoDataFrame(wave_height, crs=crs, geometry=geometry)

# save the data
wvht.to_pickle('Wave_heights')


####### plot waveheight
month='0005-05'

fig, ax = plt.subplots(figsize=(15, 15))
wvht.plot(ax=ax,column=month,legend=True,cmap='viridis',legend_kwds={'label': 'wave height, ft','orientation': "horizontal"})
world.plot(ax=ax,facecolor='none', edgecolor='black')
plt.title('Wave height for First Month of Nuclear Winter,  May of Simulation Year 5')
plt.show()
plt.tight_layout()
fig.savefig("waveheight_map.png")











